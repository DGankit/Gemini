import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface FlashcardData {
  question: string;
  answer: string;
}

export async function generateFlashcards(content: string): Promise<FlashcardData[]> {
  const prompt = `
    Extract at least 10 key "Question and Answer" pairs from the following content to help a student study.
    The questions should be clear and concise, and the answers should be informative but brief.
    
    Content:
    ${content}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              answer: { type: Type.STRING },
            },
            required: ["question", "answer"],
          },
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as FlashcardData[];
  } catch (error) {
    console.error("Error generating flashcards:", error);
    throw error;
  }
}
