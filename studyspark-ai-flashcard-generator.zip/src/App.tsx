import React, { useState } from 'react';
import { AuthProvider, useAuth } from './components/AuthContext';
import { Dashboard } from './components/Dashboard';
import { UploadZone } from './components/UploadZone';
import { StudyView } from './components/StudyView';
import { Sparkles, LogOut, BookOpen, User as UserIcon, Loader2 } from 'lucide-react';

function AppContent() {
  const { user, loading, isLoggingIn, login, logout } = useAuth();
  const [view, setView] = useState<'dashboard' | 'upload' | 'study'>('dashboard');
  const [activeSetId, setActiveSetId] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md bg-white p-10 rounded-3xl shadow-xl border border-slate-100 text-center space-y-8">
          <div className="inline-flex p-4 bg-indigo-600 rounded-3xl shadow-lg shadow-indigo-200">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black text-slate-900 tracking-tight">StudySpark AI</h1>
            <p className="text-slate-500 text-lg">Master any subject with AI-powered flashcards from your documents.</p>
          </div>
          <button
            onClick={login}
            disabled={isLoggingIn}
            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoggingIn ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
            )}
            {isLoggingIn ? 'Signing in...' : 'Sign in with Google'}
          </button>
          <p className="text-xs text-slate-400">By signing in, you agree to our terms of service.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div 
              className="flex items-center gap-2 cursor-pointer" 
              onClick={() => setView('dashboard')}
            >
              <div className="p-2 bg-indigo-600 rounded-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-black text-xl text-slate-900 tracking-tight hidden sm:block">StudySpark</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-full border border-slate-100">
                {user.photoURL ? (
                  <img src={user.photoURL} className="w-6 h-6 rounded-full" alt={user.displayName || ''} />
                ) : (
                  <UserIcon className="w-4 h-4 text-slate-400" />
                )}
                <span className="text-sm font-medium text-slate-700 hidden sm:block">{user.displayName?.split(' ')[0]}</span>
              </div>
              <button
                onClick={logout}
                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {view === 'dashboard' && (
          <Dashboard 
            user={user} 
            onSelectSet={(id) => {
              setActiveSetId(id);
              setView('study');
            }}
            onAddNew={() => setView('upload')}
          />
        )}

        {view === 'upload' && (
          <div className="space-y-6">
            <button 
              onClick={() => setView('dashboard')}
              className="text-slate-500 hover:text-indigo-600 font-medium flex items-center gap-2"
            >
              ← Back to Dashboard
            </button>
            <UploadZone 
              onSuccess={(id) => {
                setActiveSetId(id);
                setView('study');
              }} 
            />
          </div>
        )}

        {view === 'study' && activeSetId && (
          <StudyView 
            setId={activeSetId} 
            onClose={() => {
              setActiveSetId(null);
              setView('dashboard');
            }} 
          />
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
