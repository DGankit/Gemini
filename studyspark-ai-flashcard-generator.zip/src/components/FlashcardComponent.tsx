import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface FlashcardProps {
  question: string;
  answer: string;
  className?: string;
}

export function FlashcardComponent({ question, answer, className }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div 
      className={cn("perspective-1000 w-full max-w-md h-64 cursor-pointer", className)}
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        {/* Front */}
        <div className="absolute inset-0 backface-hidden bg-white rounded-2xl shadow-xl border border-slate-100 flex flex-col items-center justify-center p-8 text-center">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Question</span>
          <h3 className="text-xl font-medium text-slate-800 leading-relaxed">
            {question}
          </h3>
          <div className="mt-auto text-slate-300 text-sm italic">Click to flip</div>
        </div>

        {/* Back */}
        <div 
          className="absolute inset-0 backface-hidden bg-indigo-600 rounded-2xl shadow-xl flex flex-col items-center justify-center p-8 text-center"
          style={{ transform: 'rotateY(180deg)' }}
        >
          <span className="text-xs font-semibold text-indigo-200 uppercase tracking-wider mb-4">Answer</span>
          <p className="text-lg text-white leading-relaxed">
            {answer}
          </p>
          <div className="mt-auto text-indigo-300 text-sm italic">Click to flip back</div>
        </div>
      </motion.div>
    </div>
  );
}
