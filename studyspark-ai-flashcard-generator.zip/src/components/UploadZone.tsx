import React, { useState } from 'react';
import { FileUp, Link as LinkIcon, Loader2, Sparkles } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';
import { generateFlashcards } from '../services/geminiService';
import { db, collection, addDoc, Timestamp } from '../lib/firebase';
import { useAuth } from './AuthContext';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

interface UploadZoneProps {
  onSuccess: (setId: string) => void;
}

export function UploadZone({ onSuccess }: UploadZoneProps) {
  const { user } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);
  const [url, setUrl] = useState('');
  const [error, setError] = useState<string | null>(null);

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    return fullText;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setIsProcessing(true);
    setError(null);
    try {
      const text = await extractTextFromPDF(file);
      await processContent(text, 'pdf', file.name);
    } catch (err) {
      console.error(err);
      setError('Failed to process PDF. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url || !user) return;

    setIsProcessing(true);
    setError(null);
    try {
      // In a real app, we'd need a proxy to fetch URL content due to CORS.
      // For this demo, we'll simulate fetching or ask Gemini to use its internal tools if possible.
      // However, the prompt says "text input field for URLs". 
      // I'll use a simple fetch attempt, but it might fail CORS. 
      // Better: Use Gemini's ability to read URLs if we pass it, but standard Gemini API doesn't "fetch" URLs directly without tools.
      // I will simulate the extraction for the URL for now or use a mock if fetch fails.
      
      // Actually, I'll just pass the URL to Gemini and ask it to summarize if it can, 
      // but better to fetch text. Since CORS is an issue, I'll provide a fallback message.
      
      const response = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(url)}`);
      const data = await response.json();
      const html = data.contents;
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const text = doc.body.innerText;

      await processContent(text, 'url', url);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch URL content. CORS might be blocking the request.');
    } finally {
      setIsProcessing(false);
    }
  };

  const processContent = async (text: string, type: 'pdf' | 'url', source: string) => {
    if (!user) return;
    
    const cards = await generateFlashcards(text);
    
    // Save to Firestore
    const setRef = await addDoc(collection(db, 'flashcardSets'), {
      userId: user.uid,
      title: `Study Set: ${source.split('/').pop() || 'New Set'}`,
      sourceType: type,
      sourceValue: source,
      createdAt: Timestamp.now()
    });

    for (let i = 0; i < cards.length; i++) {
      await addDoc(collection(db, `flashcardSets/${setRef.id}/cards`), {
        ...cards[i],
        order: i
      });
    }

    onSuccess(setRef.id);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-8 p-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-900">Create New Study Set</h2>
        <p className="text-slate-500">Upload a PDF or paste a URL to generate AI flashcards</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* PDF Upload */}
        <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-slate-300 rounded-2xl cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/50 transition-all group relative overflow-hidden">
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <div className="p-3 bg-indigo-100 rounded-full mb-4 group-hover:scale-110 transition-transform">
              <FileUp className="w-6 h-6 text-indigo-600" />
            </div>
            <p className="mb-2 text-sm text-slate-700 font-semibold">Click to upload PDF</p>
            <p className="text-xs text-slate-500">Max size 10MB</p>
          </div>
          <input type="file" className="hidden" accept=".pdf" onChange={handleFileUpload} disabled={isProcessing} />
          {isProcessing && (
            <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
            </div>
          )}
        </label>

        {/* URL Input */}
        <div className="flex flex-col items-center justify-center w-full h-48 border-2 border-slate-200 rounded-2xl p-6 bg-white shadow-sm">
          <div className="p-3 bg-emerald-100 rounded-full mb-4">
            <LinkIcon className="w-6 h-6 text-emerald-600" />
          </div>
          <form onSubmit={handleUrlSubmit} className="w-full space-y-3">
            <input
              type="url"
              placeholder="Paste article URL..."
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              required
              disabled={isProcessing}
            />
            <button
              type="submit"
              disabled={isProcessing || !url}
              className="w-full bg-emerald-600 text-white py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Generate from URL
            </button>
          </form>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-100 text-red-600 rounded-xl text-sm text-center">
          {error}
        </div>
      )}
    </div>
  );
}
