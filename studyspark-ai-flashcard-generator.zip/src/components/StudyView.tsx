import React, { useEffect, useState } from 'react';
import { db, collection, query, orderBy, onSnapshot } from '../lib/firebase';
import { FlashcardComponent } from './FlashcardComponent';
import { ChevronLeft, ChevronRight, X, RotateCcw, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Card {
  id: string;
  question: string;
  answer: string;
  order: number;
}

interface StudyViewProps {
  setId: string;
  onClose: () => void;
}

export function StudyView({ setId, onClose }: StudyViewProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [setTitle, setSetTitle] = useState('');

  useEffect(() => {
    // Fetch set info
    onSnapshot(collection(db, 'flashcardSets'), (snapshot) => {
      const setDoc = snapshot.docs.find(d => d.id === setId);
      if (setDoc) setSetTitle(setDoc.data().title);
    });

    // Fetch cards
    const q = query(
      collection(db, `flashcardSets/${setId}/cards`),
      orderBy('order', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const cardsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Card[];
      setCards(cardsData);
      setLoading(false);
    });

    return unsubscribe;
  }, [setId]);

  const nextCard = () => {
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const progress = cards.length > 0 ? ((currentIndex + 1) / cards.length) * 100 : 0;

  if (loading) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const isFinished = currentIndex === cards.length - 1 && cards.length > 0;

  return (
    <div className="fixed inset-0 bg-slate-50 z-50 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="bg-white border-bottom border-slate-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-slate-600" />
          </button>
          <h1 className="font-bold text-slate-800 truncate max-w-[200px] sm:max-w-md">{setTitle}</h1>
        </div>
        <div className="text-sm font-medium text-slate-500">
          {currentIndex + 1} / {cards.length}
        </div>
      </header>

      {/* Progress Bar */}
      <div className="h-1.5 w-full bg-slate-200">
        <motion.div 
          className="h-full bg-indigo-600"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative">
        <AnimatePresence mode="wait">
          {cards.length > 0 ? (
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full flex justify-center"
            >
              <FlashcardComponent 
                question={cards[currentIndex].question}
                answer={cards[currentIndex].answer}
              />
            </motion.div>
          ) : (
            <div className="text-center text-slate-400">No cards in this set</div>
          )}
        </AnimatePresence>

        {/* Controls */}
        <div className="mt-12 flex items-center gap-8">
          <button
            onClick={prevCard}
            disabled={currentIndex === 0}
            className="p-4 bg-white rounded-full shadow-lg border border-slate-100 disabled:opacity-30 hover:scale-110 active:scale-95 transition-all text-slate-700"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          
          <button
            onClick={nextCard}
            disabled={currentIndex === cards.length - 1}
            className="p-4 bg-indigo-600 rounded-full shadow-lg shadow-indigo-200 disabled:opacity-30 hover:scale-110 active:scale-95 transition-all text-white"
          >
            <ChevronRight className="w-8 h-8" />
          </button>
        </div>

        {/* Completion State */}
        {isFinished && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-12 flex flex-col items-center"
          >
            <div className="flex items-center gap-2 text-emerald-600 font-bold mb-4">
              <CheckCircle2 className="w-5 h-5" />
              Deck Completed!
            </div>
            <button
              onClick={() => setCurrentIndex(0)}
              className="flex items-center gap-2 text-indigo-600 font-semibold hover:underline"
            >
              <RotateCcw className="w-4 h-4" />
              Restart Session
            </button>
          </motion.div>
        )}
      </main>

      {/* Footer / Shortcuts Info */}
      <footer className="p-6 text-center text-slate-400 text-xs hidden sm:block">
        Tip: Use arrow keys to navigate and Space to flip
      </footer>
    </div>
  );
}
