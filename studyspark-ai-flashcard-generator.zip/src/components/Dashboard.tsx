import React, { useEffect, useState } from 'react';
import { db, collection, query, where, orderBy, onSnapshot, User } from '../lib/firebase';
import { BookOpen, Clock, Plus, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

interface FlashcardSet {
  id: string;
  title: string;
  sourceType: string;
  createdAt: any;
}

interface DashboardProps {
  user: User;
  onSelectSet: (setId: string) => void;
  onAddNew: () => void;
}

export function Dashboard({ user, onSelectSet, onAddNew }: DashboardProps) {
  const [sets, setSets] = useState<FlashcardSet[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'flashcardSets'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const setsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as FlashcardSet[];
      setSets(setsData);
      setLoading(false);
    });

    return unsubscribe;
  }, [user.uid]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">My Study Sets</h2>
          <p className="text-slate-500">You have {sets.length} active decks</p>
        </div>
        <button
          onClick={onAddNew}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-indigo-700 transition-all flex items-center gap-2 shadow-lg shadow-indigo-200"
        >
          <Plus className="w-5 h-5" />
          New Set
        </button>
      </div>

      {sets.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
          <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900">No study sets yet</h3>
          <p className="text-slate-500 mb-6">Start by uploading a PDF or article</p>
          <button
            onClick={onAddNew}
            className="text-indigo-600 font-semibold hover:underline"
          >
            Create your first deck →
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {sets.map((set) => (
            <motion.div
              key={set.id}
              whileHover={{ y: -4 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all cursor-pointer group"
              onClick={() => onSelectSet(set.id)}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                  <BookOpen className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50 px-2 py-1 rounded">
                  {set.sourceType}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                {set.title}
              </h3>
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <Clock className="w-3.5 h-3.5" />
                {set.createdAt?.toDate().toLocaleDateString()}
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
